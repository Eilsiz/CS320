package mr

import (
	"fmt"
	"io/ioutil"
	"log"
	"net"
	"net/http"
	"net/rpc"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"
)

type Coordinator struct {
	NumReduce      int             // Number of reduce tasks
	Files          []string        // Files for map tasks, len(Files) is number of Map tasks
	MapTasks       chan MapTask    // Channel for uncompleted map tasks
	CompletedTasks map[string]bool // Map to check if task is completed
	ReduceTasks    chan ReduceTask // Channel for uncompleted reduce tasks
	Lock           sync.Mutex      // Lock for controlling shared variables
	ReducePhase    bool            // Check for whether we are mapping or reducing
}

// Starting coordinator logic
func (c *Coordinator) Start() {
	fmt.Println("Starting Coordinator, adding Map Tasks to channel")

	// Prepare initial MapTasks and add them to the queue
	for fileNum, file := range c.Files {
		mapTask := MapTask{
			Filename:  file,
			Filenum:   fileNum,
			NumReduce: c.NumReduce,
		}

		fmt.Println("MapTask", mapTask, "added to channel")

		c.MapTasks <- mapTask
		c.CompletedTasks["map_"+mapTask.Filename] = false
	}

	c.server()
}

// RPC that worker calls when idle (worker requests to know which task to request)
func (c *Coordinator) RequestTask(args *WorkerArgs, reply *TaskCheck) error {
	if c.ReducePhase {
		*reply = TaskCheck{
			TaskType: true,
		}
	} else {
		*reply = TaskCheck{
			TaskType: false,
		}
	}

	return nil

}

// RPC that worker calls when idle (worker requests a map task)
func (c *Coordinator) RequestMapTask(args *WorkerArgs, reply *MapTask) error {
	fmt.Println("Map task requested")
	c.Lock.Lock()
	defer c.Lock.Unlock()
	if len(c.MapTasks) != 0 {
		task, _ := <-c.MapTasks // check if there are uncompleted map tasks. Keep in mind, if MapTasks is empty, this will halt
		fmt.Println("Map task found,", task.Filename)
		*reply = task

		go c.WaitForMapWorker(task)
	} else {
		*reply = MapTask{
			Filenum: -1,
		}
	}

	return nil
}

// RPC that worker calls when idle (worker requests a reduce task)
func (c *Coordinator) RequestReduceTask(args *WorkerArgs, reply *ReduceTask) error {
	c.Lock.Lock()
	defer c.Lock.Unlock()
	if len(c.ReduceTasks) != 0 {
		fmt.Println("Reduce task requested")

		task, _ := <-c.ReduceTasks // check if there are uncompleted reduce tasks. Keep in mind, if MapTasks is empty, this will halt

		fmt.Println("Reduce task found, reduce_", strconv.Itoa(task.Bucket))
		*reply = task

		go c.WaitForReduceWorker(task)
	} else {
		*reply = ReduceTask{
			Bucket: -1,
		}
	}

	return nil
}

// Goroutine will wait 10 seconds and check if map task is completed or not
func (c *Coordinator) WaitForMapWorker(task MapTask) {
	time.Sleep(time.Second * 10)
	c.Lock.Lock()
	if c.CompletedTasks["map_"+task.Filename] == false {
		fmt.Println("Timer expired, task", task.Filename, "is not finished. Putting back in queue.")
		c.MapTasks <- task
	}
	c.Lock.Unlock()
}

// Goroutine will wait 10 seconds and check if reduce task is completed or not
func (c *Coordinator) WaitForReduceWorker(task ReduceTask) {
	time.Sleep(time.Second * 10)
	c.Lock.Lock()
	if c.CompletedTasks["reduce_"+strconv.Itoa(task.Bucket)] == false {
		fmt.Println("Timer expired, task", strconv.Itoa(task.Bucket), "is not finished. Putting back in queue.")
		c.ReduceTasks <- task
	}
	c.Lock.Unlock()
}

// RPC for reporting a completion of a map task
func (c *Coordinator) MapTaskCompleted(args *MapTask, reply *EmptyReply) error {
	c.Lock.Lock()
	defer c.Lock.Unlock()

	c.CompletedTasks["map_"+args.Filename] = true

	fmt.Println("Task", args, "completed")

	// If all of map tasks are completed, go to reduce phase
	// ...
	if c.checkTasksFinished() {
		c.ReducePhase = true
		fmt.Println("Now in ReducePhase!")
		c.ReduceSetup()
	}

	return nil
}

// RPC for reporting a completion of a reduce task
func (c *Coordinator) ReduceTaskCompleted(args *ReduceTask, reply *EmptyReply) error {
	c.Lock.Lock()
	defer c.Lock.Unlock()

	c.CompletedTasks["reduce_"+strconv.Itoa(args.Bucket)] = true

	fmt.Println("Task reduce_", strconv.Itoa(args.Bucket), "completed")

	return nil
}

func (c *Coordinator) ReduceSetup() {
	items, _ := ioutil.ReadDir(".")

	bucketSort := make(map[int][]string)
	for _, item := range items {
		if strings.HasPrefix(item.Name(), "mr-worker") {

			tn, _ := strconv.Atoi(string(item.Name()[len(item.Name())-1:]))
			//
			//reduceTask := ReduceTask{
			//	Filename: item.Name(),
			//	TaskNum:  tn,
			//}

			bucketSort[tn] = append(bucketSort[tn], item.Name())
		}
	}

	for bucket, mapFiles := range bucketSort {
		reduceTask := ReduceTask{
			Filenames: mapFiles,
			Bucket:    bucket,
		}

		c.ReduceTasks <- reduceTask
		c.CompletedTasks["reduce_"+strconv.Itoa(reduceTask.Bucket)] = false
	}
}

// start a thread that listens for RPCs from worker.go
func (c *Coordinator) server() {
	rpc.Register(c)
	rpc.HandleHTTP()
	//l, e := net.Listen("tcp", ":1234")
	sockname := coordinatorSock()
	os.Remove(sockname)
	l, e := net.Listen("unix", sockname)
	if e != nil {
		log.Fatal("listen error:", e)
	}
	go http.Serve(l, nil)
}

// main/mrcoordinator.go calls Done() periodically to find out
// if the entire job has finished.
func (c *Coordinator) Done() bool {
	c.Lock.Lock()
	defer c.Lock.Unlock()
	ret := false

	if !c.ReducePhase {
		return false
	} else {
		check := true
		for _, value := range c.CompletedTasks {
			if value == false {
				check = false
			}
		}
		ret = check
	}

	if ret {
		fmt.Println("******************FINSISHED!******************")
	}

	return ret
}

// create a Coordinator.
// main/mrcoordinator.go calls this function.
// nReduce is the number of reduce tasks to use.
func MakeCoordinator(files []string, nReduce int) *Coordinator {
	c := Coordinator{
		NumReduce:      nReduce,
		Files:          files,
		MapTasks:       make(chan MapTask, 100),
		ReduceTasks:    make(chan ReduceTask, 100*nReduce),
		CompletedTasks: make(map[string]bool),
		ReducePhase:    false,
	}

	fmt.Println("Starting coordinator")

	c.Start()

	return &c
}

// helper
func (c *Coordinator) checkTasksFinished() bool {
	for _, value := range c.CompletedTasks {
		if !value {
			return false
		}
	}
	return true
}
